import os
import sqlite3
import flet as ft
from components import userAvatar
from flet import (
    Row,
    Page,
    Text,
    Image,
    Column,
    colors,
    padding,
    Container,
    TextField,
    FontWeight,
    TextButton)


def index_view(page: Page):
    page.title = "Лікарі"

    title = Text("ЛІКАРІ", font_family="Merriweather", size=40, weight=FontWeight.W_600)
    title.text_align = ft.TextAlign.CENTER
    header = ft.Row(
        [
            Container(
                content=title,
                # expand=True,
                bgcolor=colors.BLUE_GREY_50,
                height=65,
                padding=padding.only(left=20),
                border=ft.border.all(1, ft.colors.GREY),
                width=1200
            ),
            Container(
                content=userAvatar,
                padding=padding.only(right=10, top=10),
                height=65,
                width=65
            ),
        ],
        width=1310
    )

    find_doctor_field = TextField(label="Пошук по списку: введіть ПІБ лікаря",
                                  width=870,
                                  height=45)

    def find_doc(e):
        db = sqlite3.connect("doctors.db")
        c = db.cursor()
        
        search_query = find_doctor_field.value
        if search_query:
            query = f"""
            SELECT name, surname, middle_name, place, specialty
            FROM docs
            WHERE name LIKE ? OR surname LIKE ? OR middle_name LIKE ?
            """
            c.execute(query, ('%' + search_query + '%', '%' + search_query + '%', '%' + search_query + '%'))
            docs = c.fetchall()
        
            # Очистка відображуваного списку лікарів
            body.controls.clear()
        
            for doc in docs:
                name_val, surname_val, middle_name_val, place_val, specialty_val = doc
        
                # Виберіть поточне зображення зі списку файлів
                current_image = f"/img/docs_img/{image_files[docs.index(doc) % len(image_files)]}"
        
                # Створення нових контролів для кожного документа
                new_name = Text(value=name_val, size=18, font_family="TimesNewRoman")
                new_surname = Text(value=surname_val, size=18, font_family="TimesNewRoman")
                new_middle_name = Text(value=middle_name_val, size=18, font_family="TimesNewRoman")
                new_place = Text(value=place_val, size=16, font_family="TimesNewRoman")
                new_specialty = Text(value=specialty_val, size=16, font_family="TimesNewRoman")
        
                new_doctor_content = Row(
                    [
                        Container(
                            Image(
                                src=current_image,
                                width=150,
                                height=150,
                            ),
                            height=150,
                            padding=ft.padding.only(left=10, top=10, bottom=10, right=20),
                            bgcolor=colors.GREY_200,
                            alignment=ft.alignment.center,
                            margin=ft.margin.only(left=30)
                        ),
                        Container(
                            Column([
                                Container(
                                    new_name,
                                    margin=ft.margin.only(top=20),
                                ),
                                Container(
                                    new_surname,
                                ),
                                Container(
                                    new_middle_name,
                                )
                            ]),
                            width=400,
                            bgcolor=colors.GREY_200,
                            height=150,
                        ),
                        Container(
                            Column([new_place]),
                            bgcolor=colors.GREY_200,
                            height=150,
                            width=400,
                        ),
                        Container(
                            new_specialty,
                            margin=ft.margin.only(right=20),
                            width=200,
                            height=150,
                            bgcolor=colors.GREY_200,
                        ),
                    ],
                    spacing=0
                )
        
                body.controls.append(new_doctor_content)
        
            db.close()
        print("World")

    find_doc_btn = TextButton("Знайти", width=110, on_click=find_doc)

    navigation = Row(
        [
            Container(content=find_doctor_field),

            Container(
                content=find_doc_btn,
                # margin=ft.margin.only(top=0, left=30),
                # padding=ft.padding.only(top=0)
            )
        ]
    )

    # name = Text("name", size=18, font_family="TimesNewRoman")
    # surname = Text("surname", size=18, font_family="TimesNewRoman")
    # middle_name = Text("maddlename", size=18, font_family="TimesNewRoman")
    #
    # place = Text("job", size=16, font_family="TimesNewRoman")
    # specialty = Text("specialty", size=16, font_family="TimesNewRoman")
    # doctor_content = Row(
    #     [
    #         Container(
    #             Image(
    #                 src="./img/docs_img/4.png",
    #                 width=150,
    #                 height=150,
    #             ),
    #             height=150,
    #             padding=ft.padding.only(left=10, top=10, bottom=10, right=20),
    #             bgcolor=colors.GREY_200,
    #             alignment=ft.alignment.center,
    #             margin=ft.margin.only(left=30)
    #         ),
    #         Container(
    #             Column([
    #                 Container(
    #                     name,
    #                     margin=ft.margin.only(top=20),
    #                 ),
    #                 Container(
    #                     surname,
    #                 ),
    #                 Container(
    #                     middle_name,
    #                 )
    #             ]),
    #             width=400,
    #             bgcolor=colors.GREY_200,
    #             height=150,
    #         ),
    #         Container(
    #             Column([place]),
    #             bgcolor=colors.GREY_200,
    #             height=150,
    #             width=400,
    #         ),
    #         Container(
    #             specialty,
    #             margin=ft.margin.only(right=20),
    #             width=200,
    #             height=150,
    #             bgcolor=colors.GREY_200,
    #         ),
    #     ],
    #     spacing=0
    # )

    body = Column(
        spacing=10,
        height=500,
        width=1250,
        scroll=ft.ScrollMode.ALWAYS,
        adaptive=True
    )

    image_files = [f for f in os.listdir('assets/img/docs_img/') if os.path.isfile(os.path.join('./img/docs_img/', f))]

    def display_docs():
        db = sqlite3.connect("doctors.db")
        c = db.cursor()
        c.execute("SELECT name, surname, middle_name, place, specialty FROM docs")
        docs = c.fetchall()
        for index, doc in enumerate(docs):
            name_val, surname_val, middle_name_val, place_val, specialty_val = doc

            # Виберіть поточне зображення зі списку файлів
            current_image = f"./img/docs_img/{image_files[index % len(image_files)]}"

            # Створення нових контролів для кожного документа
            new_name = Text(value=name_val, size=18, font_family="TimesNewRoman")
            new_surname = Text(value=surname_val, size=18, font_family="TimesNewRoman")
            new_middle_name = Text(value=middle_name_val, size=18, font_family="TimesNewRoman")
            new_place = Text(value=place_val, size=16, font_family="TimesNewRoman")
            new_specialty = Text(value=specialty_val, size=16, font_family="TimesNewRoman")

            new_doctor_content = Row(
                [
                    Container(
                        Image(
                            src=current_image,
                            width=150,
                            height=150,
                        ),
                        height=150,
                        padding=ft.padding.only(left=10, top=10, bottom=10, right=20),
                        bgcolor=colors.GREY_200,
                        alignment=ft.alignment.center,
                        margin=ft.margin.only(left=30)
                    ),
                    Container(
                        Column([
                            Container(
                                new_name,
                                margin=ft.margin.only(top=20),
                            ),
                            Container(
                                new_surname,
                            ),
                            Container(
                                new_middle_name,
                            )
                        ]),
                        width=400,
                        bgcolor=colors.GREY_200,
                        height=150,
                    ),
                    Container(
                        Column([new_place]),
                        bgcolor=colors.GREY_200,
                        height=150,
                        width=400,
                    ),
                    Container(
                        new_specialty,
                        margin=ft.margin.only(right=20),
                        width=200,
                        height=150,
                        bgcolor=colors.GREY_200,
                    ),
                ],
                spacing=0
            )

            body.controls.append(new_doctor_content)
        db.close()

    display_docs()

    main_body = Row(
        [
            Column(
                [
                    header,
                    navigation,
                    Container(body, border=ft.border.all(1))
                ]
            ),
        ],
        height=1500,
        width=900
    )

    return main_body
