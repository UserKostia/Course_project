from faker import Faker
import sqlite3
import consts.docs as docs

def fill_docs():
    faker = Faker()
    db = sqlite3.connect("doctors.db")
    c = db.cursor()
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS docs(
        id INTEGER PRIMARY KEY,
        photo BLOB,
        name VARCHAR(30),
        surname VARCHAR(40),
        middle_name VARCHAR(30),
        place VARCHAR,
        specialty VARCHAR
        )
        """
    )

    query = """
    INSERT INTO docs (photo, name, surname, middle_name, place, specialty)
    VALUES (?, ?, ?, ?, ?, ?)
    """



    docs_data = [(faker.random_element(elements="./img/docs_img"),
                    faker.random_element(elements=docs.docs_names),
                    faker.random_element(elements=docs.docs_surnames),
                    faker.random_element(elements=docs.docs_maddle_names),
                    faker.random_element(elements=docs.docs_places),
                    faker.random_element(elements=docs.docs_specialty),
                    faker.random_int(min=1, max=10)) for _ in range(500)]

    c.executemany(query, docs_data)
    db.commit()