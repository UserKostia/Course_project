import flet as ft

class userAvatar(ft.CircleAvatar):
    def __init__(self):
        super().__init__(
            ft.CircleAvatar(
                foreground_image_url="https://avatars.githubusercontent.com/u/5041459?s=88&v=4",
                content=ft.Text("FF"),
            )
        )