from utils.router import Router, DataStrategyEnum
from views.index_view import index_view
from views.patients_view import patiens_view
from views.settings_view import SettingsView
from views.doc_records import doc_records_view

router = Router(DataStrategyEnum.QUERY)

router.routes = {
  "/": index_view,
  "/doc_rec": doc_records_view,
  "/patient": patiens_view,
  "/settings": SettingsView,
}
